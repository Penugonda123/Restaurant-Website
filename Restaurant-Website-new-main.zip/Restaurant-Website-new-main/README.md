# Restaurant-Website-new
This is a dynamic website where a user can access the menu of the restaurant in online and if they want the item they have to order through the site .
